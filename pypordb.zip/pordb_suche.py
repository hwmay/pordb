# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'pordb_suche.ui'
#
# Created: Fri Jun  6 16:17:30 2008
#      by: PyQt4 UI code generator 4.3
#
# WARNING! All changes made in this file will be lost!

